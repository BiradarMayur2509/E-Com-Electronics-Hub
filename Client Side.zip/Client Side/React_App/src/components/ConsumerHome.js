export default function ConsumerHome() {

    return (
        <div>
            <h1>Consumer Home</h1>
        </div>
    )
}