export default function SellerHome() {

    return (
        <div>
            <h1>Seller Home</h1>
        </div>
    )
}