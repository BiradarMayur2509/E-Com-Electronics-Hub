//package com.example.demo.services;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//public class SellerService
//{
//	@Autowired
//	SellerRepo
//}