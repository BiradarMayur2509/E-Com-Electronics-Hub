//package com.example.demo.repositories;
//import org.springframework.data.jpa.repository.*;
//import org.springframework.stereotype.Repository;
//import org.springframework.*;
//
//import com.example.demo.entities.*;
//
//@Repository
//public interface SellerRepository extends JpaRepository<Seller ,Integer>
//{
//  @Query("select s from Seller s where seller_id= l");
//	public Seller getSeller(User l);
//}
